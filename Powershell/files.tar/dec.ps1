param([string]$part1 = "", [string]$part2="", [string]$part3="", [string]$part4="")

If($part1.Length -ne 0 -and $part2.Length -ne 0 -and $part3.Length -ne 0 -and $part4.Length -ne 0)
{
	$data = Get-Content -Path "key.bin" -Encoding byte

	$key = $part1 + $part2 + $part3 + $part4

	$enc = [System.Text.Encoding]::UTF8
	$b = $data
	$kb = $enc.GetBytes($key)

	$i = 0

	$o = ""

	foreach ($cb in $b)
	{
		$o += [convert]::ToChar($cb -bxor $kb[$i % $kb.Length])
		$i += 1
	}

	$o
}
Else
{
	Write-Host "Need key!"
}
